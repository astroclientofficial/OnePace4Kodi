import xbmcplugin
import xbmcgui
import sys
import requests

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'videos')

# Season dictionaries for both dubbed and subtitled versions
seasons_dubbed = {
    "Romance Dawn": "8tTqRmqz",
    "Orange Town": "15ZENNeo",
    "Gaimon": "FV9EJ5ve",
    "Baratie": "3LcuJRuQ",
    "Arlong Park": "6azKaGxc",
    "The Adventures of Buggy's Crew": "MbJLcYcA",
    "Loguetown": "TBaw1Tp6",
    "Reverse Mountain": "s4DEnuS5",
    "The Trials of Koby-Meppo": "b9XwPSBA",
    "Little Garden": "ABkpM5Nr",
    "Drum Island": "f4Kt9jzH",
    "Arabasta": "9MzVKBPD",
    "Jaya": "mo4QoCFk",
    "Skypiea": "AeNHWRGL",
    "Long Ring Long Land": "kTb436Vv",
    "Water Seven": "59HCmx6N",
    "The Adventures of the Straw Hat Pirates": "enZf6R88",
    "Post-War": "WjxroZSq",
    "Return to Sabaody": "JNBvnBsg"
}

seasons_subbed = {
    "Romance Dawn": "HdPqPTPH",
    "Orange Town": "mY9ec67L",
    "Syrup Village": "QqXe6SEY",
    "Gaimon": "iiTTYhCg",
    "Baratie": "dbL8ujD9",
    "Arlong Park": "nZLW8b72",
    "The Adventures of Buggy's Crew": "HnL9ip5k",
    "Loguetown": "Humwo7QP",
    "Reverse Mountain": "1kVQHoeo",
    "Whisky Peak": "xMf7ZMzv",
    "The Trials of Koby-Meppo": "Sspa78Sd",
    "Little Garden": "QYHi9mzX",
    "Drum Island": "ayrMbpVW",
    "Arabasta": "apd1qjBN",
    "Jaya": "6G1A3ufN",
    "Skypiea": "B3yZ2Yei",
    "Long Ring Long Land": "RSp1aAPY",
    "Water Seven": "WW5J2jX9",
    "Enies Lobby": "auVnaWWb",
    "Post-Enies Lobby": "ybXdFXtN",
    "Thriller Bark": "HoiVPVa9",
    "Sabaody Archipelago": "Br89QGLT",
    "Amazon Lily": "eo9wEgfe",
    "Impel Down": "B7K3GLhN",
    "The Adventures of the Straw Hat Pirates": "Sa5AHh5z",
    "Marineford": "1EvkpXLD",
    "Post-War": "bN2sHsft",
    "Return to Sabaody": "L43AyDMU",
    "Fishman Island": "gcFZLsPn",
    "Punk Hazard": "JhEhtVpm",
    "Dressrosa": "PGjvkoYC",
    "Zou": "ETokmVWr",
    "Whole Cake Island": "5pVTECas",
    "Reverie": "twsSB1xc",
    "Wano": "du8Dr9rw",
    "Egghead": "2nxix7bF"
}

def get_pixeldrain_folder_contents(folder_id):
    url = f"https://pixeldrain.com/api/list/{folder_id}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def add_directory_item(title, url, is_folder=False):
    list_item = xbmcgui.ListItem(label=title)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=is_folder)

def list_versions():
    add_directory_item("Dubbed", f"{sys.argv[0]}?action=list_seasons&version=dubbed", is_folder=True)
    add_directory_item("Subtitled", f"{sys.argv[0]}?action=list_seasons&version=subbed", is_folder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def list_seasons(version):
    seasons = seasons_dubbed if version == 'dubbed' else seasons_subbed
    for season, folder_id in seasons.items():
        url = f"{sys.argv[0]}?action=list_episodes&folder_id={folder_id}"
        add_directory_item(season, url, is_folder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def list_episodes(folder_id):
    folder_contents = get_pixeldrain_folder_contents(folder_id)
    if folder_contents:
        for item in folder_contents['files']:
            title = item['name']
            url = f"https://pixeldrain.com/api/file/{item['id']}"
            add_directory_item(title, url)
    else:
        xbmcgui.Dialog().notification("Error", "Failed to retrieve PixelDrain folder contents", xbmcgui.NOTIFICATION_ERROR)
    xbmcplugin.endOfDirectory(addon_handle)

params = dict(arg.split('=') for arg in sys.argv[2][1:].split('&')) if len(sys.argv) > 2 else {}

if 'action' in params:
    if params['action'] == 'list_seasons' and 'version' in params:
        list_seasons(params['version'])
    elif params['action'] == 'list_episodes' and 'folder_id' in params:
        list_episodes(params['folder_id'])
else:
    list_versions()